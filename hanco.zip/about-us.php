<?php include 'header.php';?>
<div class="tp-breadcrumb"><!-- tp-breadcrumb -->
	<div class="container">
		<div class="col-md-offset-3 col-md-5">
      <ol class="breadcrumb">
      <li><a href="index.html">Home</a></li>
      <li class="active">Company profile</li>
    </ol>
    </div>
	</div>
</div><!-- /.tp-breadcrumb -->

<div id="main-wrapper" class="main-wrapper"><!-- main-wrapper -->
	<div id="tp-about-page" class="tp-about-page"><!-- tp-about -->
		<div class="container">
			<div class="row tp-about-info"><!-- tp about info -->
				<div class="col-md-6 tp-about-block"><!-- tp about block -->
					<h1>Who We Are</h1>
					<p class="lead">Manufacturer & Stockist: M.S. SEAMLESS, BOILERS HYDRAULIC, ERW, PIPES FITTINGS, FLANGES & TUBES Etc.</p>
					<p style="font-size:16px;color:#afafaf;">We are a leading manufacturer & Stockist , Supplier of Broad Array of quality pipe fittings for projects and engineering services needs in diverse industry verticals such as Oil & Gas, Petrochemical, Power conventional as well as nuclear, Steel Plants, Textile, Shipping & all other process industries</p>
				</div><!-- /.tp about block -->
				<div class="col-md-6 tp-about-pic"><!-- tp about pic -->
					<img src="images/about.jpg" style="width:500px;" class="img-responsive" alt="hancopipefittings.com">
				</div><!-- /.tp about pic -->
			</div><!-- /.tp about info -->
			<div class="row tp-why-us">	<!-- tp why us -->
				<div class="col-md-12 section-title"><!-- section title -->
          <h1>Why Choose Us</h1>
					<p style="font-size:16px;color:#afafaf;">All the offered products are made available in different grades and dimensions so as to cater to the exact needs of our valued patrons. Owing to the features like accurate dimensions, sturdy construction, high torque strength, corrosion & abrasion resistance and smooth edges, our entire offered range is widely popular among the clients, located across the globe. Moreover, possessing this range, we are catering to the demands of fertilizers, pharmacy, chemical, food & beverages, oil & gas, sugar and textile industries.</p>
				</div><!-- /.section title -->
				<div class="col-md-4"><!-- why block-->
          <div class="color-box"><!-- color box-->
					<h2><i class="fa fa-cogs"></i>Technology</h2>
					<p>We are a leading manufacturer & Stockist , Supplier of Broad Array of quality pipe fittings for projects and engineering services needs in diverse industry verticals such as Oil & Gas, Petrochemical, Power conventional as well as nuclear, Steel Plants, Textile, Shipping & all other process industries.</p>
				</div><!-- /.color box-->
        </div><!-- /.why block-->
				<div class="col-md-4"><!-- why block-->
          <div class="color-box"><!-- color box -->
					<h2><i class="fa fa-dashboard"></i> Perfomance</h2>
					<p>Hanco Pipe & Fitting specializes in exclusive products and specialized services like Quick delivery, in-house testing, etc. At Hanco Pipe & Fitting, all the finished products undergo quality check in house before inspection by the client or clients authorized representative prior to the delivery of fittings.</p>
				</div><!-- /.color box -->
        </div><!-- /.why block-->
				<div class="col-md-4"><!-- why block-->
          <div class="color-box"><!-- color box -->
					<h2><i class="fa fa-users"></i>Customers</h2>
					<p>Over the years, we have always remained focused on our customers, developing our products to meet new challenges and support the market’s changing needs. At Hanco Pipe & Fitting, We aim at providing customer specific requirements by ensuring supply of quality products and services at competitive prices.</p>					
				</div><!-- /.color box -->
        </div><!-- /.why block-->
			</div><!-- /.tp why us -->
		</div>
	</div><!-- /.tp-about -->
</div><!-- /.main-wrapper -->
<?php include 'footer.php';?>
