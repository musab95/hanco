<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="description" content="Industrial web templates for the mining company and service templates. Industrial web templates are designed with high standards and bootstrap framework.">
<meta name="keywords" content="Industiral Templates, Service Templates, Bootstrap, Responsive">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>themelock.com - Indus - Industrial Responsive Templates</title>

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!--Custom template style.css-->
<link href="css/style.css" rel="stylesheet">
<link href="css/mobile.css" rel="stylesheet">

<!--Google web font css-->
<link href='http://fonts.googleapis.com/css?family=Coda:400,800' rel='stylesheet' type='text/css'>

<!--font awesome icon css-->
<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<div class="tp-top-bar" id="tp-top-bar">
  <div class="container">
    <div class="row">
      <div class="col-md-12 text-right">
        <ul class="links">
          <li><a href="#" class="highlight">24/7 Support | +1 959 603 6035</a></li>
          <li><a href="customer-services.html">Helps</a></li>
          <li><a href="faq.html">FAQ's</a></li>
          <li><a href="#">Sitemap</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="search-open">
  <div class="container">
    <div class="col-md-offset-2 col-md-8">
      <div class="input-group">
        <input type="text" class="form-control">
        <span class="input-group-btn">
        <button class="btn btn-outline" type="button">Search</button>
        </span> </div>
      <!-- /input-group --> 
    </div>
    <!-- /.col-md-12 --> 
  </div>
</div>

<!--header start-->
<div class="header-row" id="header-row">
  <div class="container">
    <div class="row tp-navigations">
      <nav class="navbar navbar-default">
        <div class="container-fluid"> 
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
            <a class="navbar-brand" href="#" title="logo"><img src="images/logo.png" alt=""></a> </div>
          
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
              <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Home <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="index.html" title="Home">Home</a></li>
                    <li><a href="index-v2.html" title="Home v2">Home v2</a></li>
                    <li><a href="index-header-01.html" title="Index Header 01">Index header 01</a></li>
                    <li><a href="index-header-02.html" title="Index Header 02">Index header 02</a></li>
                    <li><a href="index-header-03.html" title="Index Header 03">Index header 03</a></li>
                </ul>
              </li>
              <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Company Profile <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="about-us.html" title="About us">About us</a></li>
                  <li><a href="about-histroy.html" title="About histroy">About histroy</a></li>
                  <li><a href="mission.html" title="Mission">Mission</a></li>
                  <li><a href="board-members.html" title="Board members">Board members</a></li>
                </ul>
              </li>
               <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
               Products <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="product.html" title="Products">Products</a></li>
                  <li><a href="product-detail.html" title="Product Detail">Product Detail</a></li>
                </ul>
              </li>
              <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Service <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="service.html" title="Service">Service</a></li>
                  <li><a href="service_three.html" title="Service Three">Service Three</a></li>
                  <li><a href="service_four.html" title="Service Four">Service Four</a></li>
                </ul>
              </li>
              
              <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">News <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="blog.html" title="Blog">Blog</a></li>
                  <li><a href="blog-details.html" title="Blog Detail">Blog Detail</a></li>
                </ul>
              </li>
              <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Pages <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="customer-services.html" title="Customer Services">Customer Services</a></li>
                  <li><a href="request-quote.html" title="Request Quote">Request Quote</a></li>
                  <li><a href="accordion.html" title="Accordion">Accordion</a></li>
                  <li><a href="error-404.html" title="Error 404">Error</a></li>
                  <li><a href="alerts.html" title="Alerts">Alerts</a></li>
                  <li><a href="table.html" title="Tables">Tables</a></li>
                  <li><a href="tabs.html" title="Tabs">Tabs</a></li>
                  <li><a href="faq.html" title="Faq">Faq</a></li>
                </ul>
              </li>
              <li><a href="contact-us.html" title="Contact us">Contact us</a></li>
              <li><a href="#" class="search highlight" title="search"><i class="fa fa-search"></i></a></li>
            </ul>
          </div>
          <!-- /.navbar-collapse --> 
        </div>
        <!-- /.container-fluid --> 
      </nav>
    </div>
  </div>
</div>
<!--header Close-->

<div class="tp-breadcrumb"><!-- tp-breadcrumb -->
  <div class="container">
    <div class="col-md-offset-3 col-md-5">
      <ol class="breadcrumb">
        <li><a href="index.html">Home</a></li>
        <li class="active">404 error page</li>
      </ol>
    </div>
  </div>
</div>
<!-- /.tp-breadcrumb -->

<div id="main-wrapper" class="main-wrapper"><!-- main-wrapper -->
  <div id="tp-error-page" class="tp-error-page"><!-- Error-page -->
    <div class="container">
          <div class="row">
            <div class="col-md-offset-1 col-md-10">
              	<h1>4<i class="fa fa-gear"></i>4</h1>
                <div class="error-info">
                	<h2>Opps ! we can’t find what you’re looking for</h2>
                    <p>Lorem ipsum dolol standards in the productio orem imet, consectetur adipisicing elit, do eiusmod tempor incididunt ut lSuspendisse in erat ut quam aliquam vulputate quis eu sem. Integer quis tempor erat. </p>
                    <a href="#" class="btn btn-outline">go to the homepage</a>
                </div>
            </div>
          </div>
    </div>
  </div>
  <!-- /.Error-page --> 
</div>
<!-- /.main-wrapper -->
<!-- Footer section start-->
<div id="footer" class="footer-section">
  <div class="container">
    <div class="row"><!--footer section first start-->
      <div class="col-md-3 tp-ft-about"><!-- Footer about block start -->
        <div class="ft-logo"> <img src="images/logo.png" alt=""></div>
        <div class="address"><!--Address start-->
          <ul>
            <li>4578 Marmora Road, MG Glasgow 
              Lesten- D04 89GR,  Australia</li>
            <li> Phone :     800-2345-6789  /  6889 <br>
              800-2345-6789  /  6890</li>
            <li>Fax :            800-2345-6789  /  6889 <br>
              800-2345-6789  /  6890</li>
            <li>E-Mail : info@indusmining.com</li>
          </ul>
        </div>
        <!--Address End--> 
        
      </div>
      <!-- Footer about block end --> 
      <!--Investor relation block start-->
      <div class="col-md-3 tp-investor-relation">
        <h2>Quick Links</h2>
        <ul>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Company Profile</a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="#">Products </a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="#">Services </a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="#">News </a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="#">Contact</a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="#">Career</a></li>
        </ul>
      </div>
      <!--Investor relation block end--> 
      <!--Pages links block start-->
      <div class="col-md-3 twitter-widget">
        <h2>Twitter Indus</h2>
        <ul>
          <li><a href="#">@mona01</a>the gold for mining 
            Perfomance <a href="">http://t.co/2ctjhv45</a> <small>2 days ago</small> </li>
          <li><a href="#">@mona01</a>the gold for mining 
            Perfomance <a href="">http://t.co/2ctjhv45</a> <small>3 days ago</small> </li>
        </ul>
      </div>
      <!--Pages links block end--> 
      <!--Informations links block start-->
      <div class="col-md-3 tp-ft-newsletter">
        <h2>Sign up For Newsletter</h2>
        <p>Get the latest report about the project and company profile.</p>
        <form role="form" action="newsletter.php" method="post">
        <div class="form-group">
        <input name="email" type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" required > 
					    <span class="input-group-btn">
						<button type="submit" class="btn btn-submit">Subscribe</button>
					    </span>
					</div>
        </form>
      </div>
      <!--Informations links block end--> 
    </div>
    <!--footer section first end--> 
    
  </div>
</div>
<!-- Footer section end--> 
<!-- Tiny Footer start-->
<div id="tiny-footer" class="tiny-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <p class="copyright-ct">© 2014 Indusminingcompany   |   Privacy policy</p>
      </div>
      <div class="col-md-6">
        <ul class="social-icon-ft pull-right">
          <li><a href="#" title="Facebook"><i class="fa fa-facebook-square"></i></a></li>
          <li><a href="#" title="'Twitter"><i class="fa fa-twitter-square"></i></a></li>
          <li><a href="#" title="Googel Plus"><i class="fa fa-google-plus-square"></i></a></li>
          <li><a href="#" title="Rss Square"><i class="fa  fa-rss-square"></i></a></li>
          <li><a href="#" title="Linkedin Square"><i class="fa  fa-linkedin-square"></i></a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- Tiny Footer End--> 
<a href="#0" class="cd-top">Top</a>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="js/search.js"></script> 
<script src="js/modernizr.js"></script> <!-- Modernizr -->
<script src="js/main.js"></script> <!-- Gem jQuery -->
<script type="text/javascript" src="js/bootstrap.min.js"></script>

</body>
</html>
