<!-- Footer section start-->
<div id="footer" class="footer-section">
  <div class="container">
    <div class="row"><!--footer section first start-->
      <div class="col-md-6 tp-ft-about"><!-- Footer about block start -->
        <div class="ft-logo"><img src="images/hanco-logo.png" alt="hancopipefittings" style="margin-top: -49px;"></div>
        <div class="address"><!--Address start-->
          <ul>
            <li>Plot No.&nbsp; 1353,&nbsp; 1354,&nbsp; 1355,&nbsp; Opp. Ganpati Karkhana,&nbsp; Road No. 15,&nbsp; Kalamboli,<br> Navi Mumbai, &nbsp; Raigad. 410218</li>
            <li> Tel. Off. &nbsp; 27421475 &nbsp; / &nbsp; 27421474 <br>
                 Mob. No.  &nbsp; 9930667501 &nbsp; / &nbsp; 9833027708</li>
            <li> Tele Fax No. : &nbsp; 23735795</li>
            <li>E-Mail : info@hancopipefittings.com</li>
          </ul>
        </div>
        <!--Address End--> 
        
      </div>
      <!-- Footer about block end --> 
      <!--Investor relation block start-->
      <div class="col-md-6 tp-investor-relation">
        <h2>Quick Links</h2>
        <ul>
          <li><i class="fa fa-angle-double-right"></i><a href="tee.php">TEE </a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="cap.php">CAP </a></li>
          <li><i class="fa fa-angle-double-right"></i><a href="elbow.php">ELBOW</a></li>
          <li> <i class="fa fa-angle-double-right"></i><a href="reducer.php">REDUCER </a></li>          
        </ul>
      </div>
      <!--Investor relation block end--> 
    </div>
    <!--footer section first end--> 
    
  </div>
</div>
<!-- Footer section end--> 
<!-- Tiny Footer start-->
<div id="tiny-footer" class="tiny-footer">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <p class="copyright-ct" style="text-align: center; color: #666;">© 2016 &nbsp; All Rights Reserved &nbsp; | &nbsp; Hanco Pipe & Fitting  &nbsp; | &nbsp;  <a href="#">hancopipefittings.com</a></p>
      </div>
      <!-- <div class="col-md-6">
        <ul class="social-icon-ft pull-right">
          <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
          <li><a href=""><i class="fa fa-twitter-square"></i></a></li>
          <li><a href=""><i class="fa fa-google-plus-square"></i></a></li>
          <li><a href=""><i class="fa  fa-rss-square"></i></a></li>
          <li><a href=""><i class="fa  fa-linkedin-square"></i></a></li>
        </ul>
      </div> -->
    </div>
  </div>
</div>
<!-- Tiny Footer End--> 
<a href="#0" class="cd-top">Top</a>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- Include all compiled plugins (below), or include individual files as needed --> 

<script type="text/javascript" src="js/jquery.dataTables.js"></script> 
<script type="text/javascript" src="js/bootstrap.min.js"></script> 
<script type="text/javascript" src="js/owl.carousel.js"></script> 
<!-- isotope portfolio filter --> 
<script src="js/jquery.isotope.min.js" type="text/javascript"></script> 
<script src="js/filter-script.js" type="text/javascript"></script> 

<!--Camera JS Script--> 
<script type="text/javascript" src="js/jquery.min.js"></script> 
<script type="text/javascript" src="js/jquery.mobile.customized.min.js"></script> 
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script> 
<script type="text/javascript" src="js/camera.js"></script> 
<script type="text/javascript" src="js/script.js"></script> 
<script type="text/javascript" src="js/search.js"></script>
<script type="text/javascript" src="js/camera-script.js"></script>
<script src="js/modernizr.js"></script> <!-- Modernizr -->
<script src="js/main.js"></script> <!-- Gem jQuery -->
</body>
</html>
