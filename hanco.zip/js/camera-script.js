jQuery(function(){
 jQuery('#camera_wrap_1').camera({
                
                fx: 'scrollLeft',
                time: 5000,
                loader: 'bar',
                loaderColor: '#fde230',
                hover:false,
                playPause: false,
                height: '34%'
        
        });
        });