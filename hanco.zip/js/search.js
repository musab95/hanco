// JavaScript Document

//show and hide search bar
$( document ).ready(function() {

  $(".search").click(function(){
    $(".search-open").slideToggle('1000');
  });

  });